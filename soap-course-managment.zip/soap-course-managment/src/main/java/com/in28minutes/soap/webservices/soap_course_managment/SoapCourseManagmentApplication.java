package com.in28minutes.soap.webservices.soap_course_managment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapCourseManagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapCourseManagmentApplication.class, args);
	}

}
