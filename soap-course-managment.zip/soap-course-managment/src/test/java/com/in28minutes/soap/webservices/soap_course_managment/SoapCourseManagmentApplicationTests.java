package com.in28minutes.soap.webservices.soap_course_managment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapCourseManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
